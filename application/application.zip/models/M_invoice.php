<?php
defined('BASEPATH') or exit('No direct script access allowed');

// table: invoice. related to order
class M_invoice extends CI_Model
{
  public function __construct()
  {
    parent::__construct();
    $this->load->model('M_app');
  }

  public function getId($table)
  {
    $q = $this->db->query("SELECT MAX(id) AS kd_max FROM $table")->row_array();
    $tmp = ((int) $q['kd_max']) + 1;
    return sprintf("%04s", $tmp);
  }

  public function get_invoice_by_orderid($order_id)
  {
    $this->db->trans_start();

    $order = $this->db->select('*')
      ->from('invoices')
      ->where(['order_id' => $order_id])
      ->get()->row_array();
    $this->db->trans_complete();

    return $order;
  }

  public function get_order($user_id = null)
  {
    $this->db->trans_start();
    $order = $this->db->select('*')
      ->from('orders o')
      ->where('o.customer_id', $user_id)
      ->get()
      ->result_array();
    $this->db->trans_complete();

    return $order;
  }

  public function confirm_payment($order_id)
  {
    $this->db->trans_start();

    // if accepted, invoice status set to confirm
    $this->db->update('invoices', ['status' => 'confirm'], ['order_id' => $order_id]);

    // if accepted, order status set to processing
    $this->db->update('orders', ['status' => 'payment accepted'], ['id' => $order_id]);
    $this->db->trans_complete();

    if ($this->db->trans_status()) {
      // $this->M_app->log_activity(' import data baru ' . $activity);
      return true;
    } else {
      return false;
    }
  }

  /**
   * Reject payment for the given order.
   *
   * This sets the related invoice to an unpaid/rejected state (is_paid=2)
   * and updates the order status to "payment rejected". A transaction is
   * used to ensure both updates succeed or fail together.
   *
   * @param int|string $order_id
   * @return bool true on success, false on failure
   */
  public function reject_payment($order_id)
  {
    $this->db->trans_start();

    // mark invoice as rejected (is_paid = 2) and optionally update status
    $this->db->update(
      'invoices',
      ['is_paid' => 2, 'status' => 'rejected'],
      ['order_id' => $order_id]
    );

    // set order status so front‑end can act accordingly
    $this->db->update('orders', ['status' => 'payment rejected'], ['id' => $order_id]);

    $this->db->trans_complete();

    return $this->db->trans_status();
  }

  public function data_invoice($data)
  {
    $data = [
      'order_id' => $data['order_id'],
      'order_price' => $data['order_price'],
      'created_at' => $this->M_app->datetime(),
      'expired_at' => date('Y-m-d H:i:s', strtotime('+1 day')),
      'payment_id' => $data['payment_id'],
      'payment_method' => $data['payment_method'],
      'other' => $data['other'],
      'is_paid' => $data['is_paid'],

    ];

    return $data;
  }

  public function update_order($foto, $foto_default)
  {
    $prod = [
      'product_id' => $this->input->post('product_id'),
      // 'qty' => $this->input->post('qty'),
      'status' => $this->input->post('status'),
      'sku' => $this->input->post('sku'),
      'updated_at' => $this->M_app->datetime(),
    ];

    return $prod;
  }

  public function save_invoice($table, $input, $activity)
  {
    $data = $this->data_invoice($input);

    $this->db->trans_start();
    // $this->db->insert('product', $user);
    $this->db->insert($table, $data);

    $this->db->trans_complete();

    if ($this->db->trans_status()) {

      //belum dibuat tabel nya
      // $this->M_app->log_activity(' menambahkan data baru ' . $activity . ' [' . $prod['id'] . ']');
      return true;
    } else {
      return false;
    }
  }

  public function update_product($foto_default, $table, $activity)
  {
    $id = $this->input->post('id');

    $foto = $this->input->post('foto_product');

    $data = $this->update_order($foto, $foto_default);

    $this->db->trans_start();
    $this->db->where(['id' => $id]);
    $this->db->update($table, $data);

    $this->db->trans_complete();

    if ($this->db->trans_status()) {
      // $this->M_app->log_activity(' mengubah data ' . $activity . ' [' . $id . ']');
      return true;
    } else {

      return false;
    }
  }

  public function upload_bukti_transfer($id, $order_id)
  {
    $foto_bukti_transfer = $this->input->post('base64_input');

    $data = [
      'bukti_transfer' => $foto_bukti_transfer,
      'is_paid' => 1,
    ];

    $this->db->trans_start();
    $this->db->update('orders', ['status' => 'paid'], ['id' => $order_id]);
    $this->db->update('invoices', $data, ['id' => $id]);
    $this->db->trans_complete();
    if ($this->db->trans_status()) {
      // $this->M_app->log_activity(' import data baru ' . $activity);
      return true;
    } else {
      return false;
    }
  }

  public function insert_batch($prod, $identities, $datas, $table, $activity)
  {
    $this->db->trans_start();
    $this->db->insert_batch('product', $prod);
    $this->db->trans_complete();

    if ($this->db->trans_status()) {
      // $this->M_app->log_activity(' import data baru ' . $activity);
      return true;
    } else {
      return false;
    }
  }

  public function delete_invoice($id, $table, $activity)
  {
    $data = [
      'deleted_at' => $this->M_app->datetime(),
    ];

    $this->db->trans_start();
    $this->db->where(['id' => $id]);
    $this->db->update('product', $data);

    $this->db->trans_complete();

    if ($this->db->trans_status()) {
      // $this->M_app->log_activity($activity);
      return true;
    } else {
      return false;
    }
  }
}
